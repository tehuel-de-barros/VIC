package vic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ModeloPedido {
    
    public String producto;
    public int cantidad;
    public int id_clien;
    public int id_stock;

    public ModeloPedido() {
    }

    public ModeloPedido(String producto, int cantidad, int id_clien, int id_stock) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.id_clien = id_clien;
        this.id_stock = id_stock;
    }
    
    public void insert(){
        Connection connection = null;
        try {
            connection = DBConnector.getConnection();
            
            if(hayStock(connection, id_stock, cantidad)){
                String sql = "INSERT INTO Pedidos (producto, cantidad, id_clien, id_stock, fecha) VALUES (?, ?, ?, ?, CURDATE())";
                PreparedStatement pstmt = connection.prepareStatement(sql);
                
                producto = calcularProducto(connection, id_stock);
                pstmt.setString(1, producto);
                pstmt.setInt(2, cantidad);
                pstmt.setInt(3, id_clien);
                pstmt.setInt(4, id_stock);

                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Todo OK");
                    JOptionPane.showMessageDialog(null, "Pedido realizado con éxito");
                    connection.close();
                }
            } else JOptionPane.showMessageDialog(null, "No suficiente stock del producto seleccionado");
            
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "No se puede ingresar en este momento...");
        }
    }
    
    private boolean hayStock(Connection connection, int id_stock, int cantidad) throws SQLException {
        String sql = "SELECT cantidad FROM Stock WHERE id_stock = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, id_stock);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        return resultSet.getInt(1) >= cantidad; 
    }
    
    public boolean clienteExiste() throws SQLException {
        Connection connection = DBConnector.getConnection();
        String sql = "SELECT COUNT(*) FROM Clientes WHERE id_clien = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, id_clien);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        return resultSet.getInt(1) == 1; 
    }
    
    public boolean productoExiste() throws SQLException {
        Connection connection = DBConnector.getConnection();
        String sql = "SELECT COUNT(*) FROM Stock WHERE id_stock = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, id_stock);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        return resultSet.getInt(1) == 1; 
    }
    
    private String calcularProducto(Connection connection, int id_stock) throws SQLException {
        String sql = "SELECT producto FROM Stock WHERE id_stock = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, id_stock);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        return resultSet.getString(1); 
    }
    
}
