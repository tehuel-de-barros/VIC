package vic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector {
    private static String url = "jdbc:mysql://localhost:3306/vic?serverTimezone=UTC";
    private static String user = "root";
    private static String password = "";
    private static String driver = "com.mysql.cj.jdbc.Driver";
    
    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName(driver); 
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Se conectó correctamente a la base de datos.");
        } catch (SQLException e) {
            System.out.println("Error al intentar establecer la conexión: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el controlador JDBC: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error desconocido: " + e.getMessage());
        }
        
        return connection;
    }
}

