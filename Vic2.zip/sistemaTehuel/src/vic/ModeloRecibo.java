package vic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ModeloRecibo {
    
    public int id_fac;
    public int monto;

    public ModeloRecibo() {
    }

    public ModeloRecibo(int id_fac, int monto) {
        this.id_fac = id_fac;
        this.monto = monto;
    }
    
    public void insert(){
        Connection connection = null;
        try {
            connection = DBConnector.getConnection();
            
            if(facturaExiste(connection, id_fac)){
                String sql = "INSERT INTO Recibos (id_fac, monto, fecha) VALUES (?, ?, CURDATE())";
                PreparedStatement pstmt = connection.prepareStatement(sql);
                
                monto = calcularMonto(connection, id_fac);
                pstmt.setInt(1, id_fac);
                pstmt.setInt(2, monto);

                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Todo OK");
                    connection.close();
                }
                    
                JOptionPane.showMessageDialog(null, "Documentos realizados con éxito");
                
            } else JOptionPane.showMessageDialog(null, "La factura no existe");
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "No se puede ingresar en este momento...");
        }
    }
    
    private boolean facturaExiste(Connection connection, int id_fac) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Facturas WHERE id_fac = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, id_fac);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        return resultSet.getInt(1) == 1; 
    }
    
    private int calcularMonto(Connection connection, int id_fac) throws SQLException {
        String sql = "SELECT monto FROM Facturas WHERE id_fac = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, id_fac);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        return resultSet.getInt(1); 
    }
    
}
