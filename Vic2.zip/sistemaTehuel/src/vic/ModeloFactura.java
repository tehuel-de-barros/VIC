package vic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ModeloFactura {
    
    public int id_pedido;
    public int monto;

    public ModeloFactura() {
    }

    public ModeloFactura(int id_pedido, int monto) {
        this.id_pedido = id_pedido;
        this.monto = monto;
    }
    
    public void insert(){
        Connection connection = null;
        try {
            connection = DBConnector.getConnection();
            
            if(pedidoExiste(connection, id_pedido)){
                
                String sql = "INSERT INTO Facturas (id_pedido, monto, fecha) VALUES (?, ?, CURDATE())";
                PreparedStatement pstmt = connection.prepareStatement(sql);

                pstmt.setInt(1, id_pedido);
                pstmt.setInt(2, monto);

                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Todo OK");
                    connection.close();
                }

                JOptionPane.showMessageDialog(null, "Factura realizada con éxito");
                
            } else JOptionPane.showMessageDialog(null, "El ID de pedido no existe");
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "No se puede ingresar en este momento...");
        }
    }
    
    private boolean pedidoExiste(Connection connection, int id_pedido) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Pedidos WHERE id_pedido = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, id_pedido);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        return resultSet.getInt(1) == 1; 
    }
    
}
