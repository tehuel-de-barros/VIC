package vic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ModeloStock {
    public String producto;
    public int cantidad;

    public ModeloStock() {
    }

    public ModeloStock(String nombre, int cantidad) {
        this.producto = nombre;
        this.cantidad = cantidad;
    }
    
    public void insert(){
        Connection connection = null;
        try {
            connection = DBConnector.getConnection();
            
            if(!productoExiste(connection, producto)){
                String sql = "Update Stock SET cantidad = cantidad + ? WHERE producto = ?";
                PreparedStatement pstmt = connection.prepareStatement(sql);

                
                pstmt.setInt(1, cantidad);
                pstmt.setString(2, producto);
                
                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Todo OK");
                    JOptionPane.showMessageDialog(null, "Stock pedido con éxito");
                    connection.close();
                }
            } else {
                String sql = "INSERT INTO Stock (producto, cantidad) VALUES (?, ?)";
                PreparedStatement pstmt = connection.prepareStatement(sql);

                pstmt.setString(1, producto);
                pstmt.setInt(2, cantidad);

                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Todo OK");
                    JOptionPane.showMessageDialog(null, "Stock pedido con éxito");
                    connection.close();
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "No se puede ingresar en este momento...");
        }
    }
    
    private boolean productoExiste(Connection connection, String producto) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Stock WHERE producto = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setString(1, producto);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        int count = resultSet.getInt(1);
        return count == 0; 
    }
    
}
