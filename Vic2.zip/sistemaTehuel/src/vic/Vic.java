package vic;

import gui.Inicio;
import java.sql.Connection;
import java.sql.SQLException;

public class Vic {
    
    public static void main(String[] args) {
        Connection connection = DBConnector.getConnection();

        try {
            connection.close();
        } catch (SQLException e) {
        }
        
        Inicio inicio = new Inicio();
        inicio.setVisible(true);
        
    }
    
}
