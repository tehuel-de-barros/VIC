package vic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ModeloCliente {
    public String nom;
    public String tel;

    public ModeloCliente() {
    }

    public ModeloCliente(String nom, String tel) {
        this.nom = nom;
        this.tel = tel;
    }
    
    public void insert(){
        Connection connection = null;
        try {
            connection = DBConnector.getConnection();
            
            String sql = "INSERT INTO Clientes (nom, tel) VALUES (?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);

            pstmt.setString(1, nom);
            pstmt.setString(2, tel);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Todo OK");
                JOptionPane.showMessageDialog(null, "Cliente agregado con éxito");
                connection.close();
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "No se puede ingresar en este momento...");
        }
    }
    
    public boolean clienteExiste() throws SQLException {
        Connection connection = DBConnector.getConnection();
        String sql = "SELECT COUNT(*) FROM Clientes WHERE nom = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setString(1, nom);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        int count = resultSet.getInt(1);
        return count == 1; 
    }
    
}
