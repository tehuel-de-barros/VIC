package vic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ModeloRemito {
    
    public int id_fac;
    public int id_stock;

    public ModeloRemito() {
    }
    
    public ModeloRemito(int id_fac, int id_stock) {
        this.id_fac = id_fac;
        this.id_stock = id_stock;
    }
    
        
    public void insert(){
        Connection connection = null;
        try {
            connection = DBConnector.getConnection();
            
            String sql = "INSERT INTO Remitos (id_fac, id_stock, fecha) VALUES (?, ?, CURDATE())";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            
            id_stock = calcularStock(connection);
            pstmt.setInt(1, id_fac);
            pstmt.setInt(2, id_stock);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Todo OK");
                actualizarStock(connection);
                connection.close();
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private int calcularStock(Connection connection) throws SQLException {
        String sql = "SELECT s.id_stock FROM Stock AS s INNER JOIN Pedidos AS p ON s.id_stock = p.id_stock INNER JOIN Facturas AS f ON p.id_pedido = f.id_pedido WHERE f.id_fac = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, id_fac);
        ResultSet resultSet = pstmt.executeQuery();
        resultSet.next();
        return resultSet.getInt(1); 
    }
    
    private int actualizarStock(Connection connection) throws SQLException {
        String sql = "UPDATE Stock SET cantidad = cantidad - (SELECT cantidad FROM Pedidos AS p INNER JOIN Facturas AS f ON p.id_pedido = f.id_pedido INNER JOIN Remitos AS r ON f.id_fac = r.id_fac WHERE r.id_rem = (SELECT MAX(id_rem) FROM remitos)) WHERE id_stock = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id_stock);
            return pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    
}
